# config/secrets.py

# Home Assistant
HA_HOST = 'localhost'
HA_PORT = 8123
HA_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiI5NDk1ODY4N2E0NDI0YmMwYWJmNjlkZDgyYzk1ZGU4NSIsImlhdCI6MTczMTgwNjMwNywiZXhwIjoyMDQ3MTY2MzA3fQ.CiF9jmx8ylU6fiNGPxKpWdRbLEKvMJ4WbeCxExOsdwk"

# MongoDB
MONGO_HOST = 'localhost'
MONGO_PORT = 27017
MONGO_DB_NAME = 'home_assistant'
MONGO_USERNAME = 'admin'
MONGO_PASSWORD = 'password'

# OpenAI
OPENAI_API_KEY = "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"
AI_MODEL_NAME = "gpt-4o-mini"